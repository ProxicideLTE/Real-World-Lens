//
//  LensLookupTableTests.h
//  LensLookupTableTests
//
//  Created by SIRT on 12-07-26.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface LensLookupTableTests : SenTestCase

@end
