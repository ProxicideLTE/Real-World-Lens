//
//  AppNavigationController.h
//  LensLookupTable
//
//  Created by SIRT on 12-08-15.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

//  Class provides the Navigation Controller for the table views in this app.
@interface AppNavigationController : UINavigationController

@end
